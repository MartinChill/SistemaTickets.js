# Sistema de Tickets

*Un sistema de tickets avanzado usando bases de datos!*
**Crea y elimina tickets rapidamente!**

***

### [**DISCORD DE SOPORTE**](https://discord.gg/MBPsvcphGf)

***

## Características:
> ✓ Comando para ver el PING
> 
> ✓ Comando para crear SETUP
> 
> ✓ Código de USO LIBRE
> 
> ✓ Base de datos rapida y segura!
> 
> ✓ Funciona en Replit.com y en cualquier hosting VPS
> 
> ✓ Funcionando en Discord.JS V13

## GUÍA PARA INSTALAR
 
> - ` 0. ` Tener **node.js v16.6 o mayor**
> 
> - ` 1. ` En el archivo `./config/config.json` Ajusta el TOKEN y el PREFIJO
> 
> - ` 2. ` `npm install` para instalar las dependencias
> 
> - ` 3. ` `node .` para inicializar el Bot

***

## [Servidor de Discord 😎](https://discord.gg/MBPsvcphGf) | [Sitio WEB](https://dewstouh.github.io/niby)
<a href="https://discord.gg/MBPsvcphGf"><img src="https://cdn.discordapp.com/avatars/879388961892618310/ceaa05c1871c6d98313ba36080645168.webp?size=512"></a>

***

## APOYAME

> Siempre puedes ayudarme usando cualquiera **de mis Bots de Discord**

[![Niby | El mejor bot todo en 1 2022](https://cdn.discordapp.com/avatars/879388961892618310/ceaa05c1871c6d98313ba36080645168.webp?size=512)](https://dewstouh.github.io/niby)

# Creditos

> Si vas a usar este bot, dame creditos!

